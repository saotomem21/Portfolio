
Once you have created a .patt file, you can import it to Metrica Play via [Metrica Cloud](https://cloud.metrica-play.com/). To do so you need to select the Video Project you want to upload a file and upload it under the more options section (three dots all the way to the left of the Video Project). You'll get a notification informing you if the upload was or wasn't successful. 

Once the file is uploaded, you can go to Metrica Play and download the Video Project from the DB Manager. If you already did that, you can:

1. Select the Video Project in the Video manager, and then on Pattern Events more options select Retry download.  
2. Close and open the application again and will get a notification informing you there is a new file and you can click directly there to download it.

If you had uploaded a file already and want to upload a new one, go to Cloud, delete the previously uploaded file and do any of the two steps described above. 
# Changelog

## 0.1.1 (2020-10-19)
- More Zones (before only one was defined)
- Users can now define their own Areas as well.
- Methods that use to take only one Zone, now can take several Zones, Areas, or a combination of both.
- We change the way the Zones enum worked. Now the Areas (before called boxes) are the value of the type.
- We changes Box, by a new class Area, which has an area type as attribute.

